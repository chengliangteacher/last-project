var mongoose=require("mongoose")

module.exports.getuser=async (data)=>{
    const usersmodel=mongoose.model('users')
    return await usersmodel.find()
}