var express = require('express');
var router = express.Router();

let { getuser } = require('../service/service.js')

router.post('/users', async function (req, res, next) {
    console.log(res.body)
    res.send(await getuser(res.body))
});

module.exports = router;