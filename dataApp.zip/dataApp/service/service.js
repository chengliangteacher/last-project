let { getuser } = require('../dao/usersDao.js')

module.exports.getuser = async (users) => {
    return await getuser(users)
};